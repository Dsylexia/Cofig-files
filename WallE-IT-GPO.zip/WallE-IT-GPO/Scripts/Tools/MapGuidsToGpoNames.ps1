﻿<#
.SYNOPSIS
Map GUIDs in a GPO backup to GPO display names

.DESCRIPTION
A GPO backup is written to a directory named with a newly-generated GUID. The GPO's display name is embedded in a "backup.xml" file in that directory. This script maps display names to GUIDs and outputs them as a sorted list or as formatted text.

.PARAMETER rootdir
Path to the directory containing one or more GPO backups.

.PARAMETER formatOutput
If this switch is specified, this script outputs text as a formatted and auto-sized table.
If this switch is not specified, this script outputs a SortedList object that can be further manipulated.

.EXAMPLE
PS C:\> MapGuidsToGpoNames.ps1 C:\GPOs\Windows-10-2004-Security-Baseline-FINAL\GPOs -formatOutput                                
Name                                                                       Value
----                                                                       -----
C_Software								   {1CA89B63-221B-458A-A328-22AFEBE09C86}
U_RemovableDrive							   {D6044A52-1EC8-4138-AE28-45D69603AC52}
U_RegEdit								   {5730E094-2D43-4EC4-ADAE-15973AB890F6}
U_CMD									   {015E00D9-E64B-45E1-B7CF-07A81232EF53}
U_ControlPanel								   {BC21D215-366A-4FFB-B5BD-F38ABF16032E}
C_Password								   {3201E8AE-2C71-4E59-BFA3-36D59E372D61}
C_LanManger Hash							   {ED3D7FE2-C7E1-4F55-85B9-C3DB35C0B1F7}
C_GuestAccount								   {C55BDB7D-6D53-4C44-808F-12B0C1C042C4}
U_ActiveDirectory							   {C44468A0-9FD0-44DA-8EB4-1CD45C277BD9}
U_Notification								   {E224ECDA-EF80-4ECF-A728-6F899EA90952}
C_InternetExplorer							   {9FA29A98-3933-4E13-8FE3-7C60AD570D7F}
U_InternetExplorer							   {6643D42B-DFD1-4B68-B2BE-C7FA0CC104A8}
C_BitLocker								   {D97C000C-DBDD-4979-A49D-FF70B9DB99D6}
C_ComputerSettings							   {D56BA2CE-173F-423B-90E2-684D84B0E900}
C_CredentialGuard							   {D985BAC0-D87A-4C10-807A-A05D96998166}
C_AntiVirus								   {37AD2C58-B5E3-4799-B575-BC03B2B55C8D}

#>

param(
    [parameter(Mandatory=$true)]
    [String]
    $rootdir,

    [switch]
    $formatOutput
    )

$results = New-Object System.Collections.SortedList
Get-ChildItem -Recurse -Include backup.xml $rootdir | ForEach-Object {
    $guid = $_.Directory.Name
    $displayName = ([xml](gc $_)).GroupPolicyBackupScheme.GroupPolicyObject.GroupPolicyCoreSettings.DisplayName.InnerText
    $results.Add($displayName, $guid)
}

if ($formatOutput)
{
    $results | Format-Table -AutoSize
}
else
{
    $results
}
