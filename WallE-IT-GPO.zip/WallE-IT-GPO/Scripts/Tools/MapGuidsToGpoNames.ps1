﻿<#
.SYNOPSIS
Map GUIDs in a GPO backup to GPO display names

.DESCRIPTION
A GPO backup is written to a directory named with a newly-generated GUID. The GPO's display name is embedded in a "backup.xml" file in that directory. This script maps display names to GUIDs and outputs them as a sorted list or as formatted text.

.PARAMETER rootdir
Path to the directory containing one or more GPO backups.

.PARAMETER formatOutput
If this switch is specified, this script outputs text as a formatted and auto-sized table.
If this switch is not specified, this script outputs a SortedList object that can be further manipulated.

.EXAMPLE
PS C:\> MapGuidsToGpoNames.ps1 C:\GPOs\Windows-10-2004-Security-Baseline-FINAL\GPOs -formatOutput                                
Name                                                                       Value
----                                                                       -----
AC_AntiVirus								   {D062F7B3-029F-4777-9756-250D99E2FECF}
AC_BitLocker								   {539EEBCF-1A2F-4246-AFD2-F69095295DF8}
AC_CredentialGuard							   {8231F7F8-2058-42C3-8A04-7F6A3B2B0B2D}
AC_GuestAccount								   {FEC40294-4EB6-42C0-89EB-74A5585FC304}
AC_InfraSecurity							   {95BF0759-AF3D-4670-9444-8CCD94814837}
AC_InternetExplorer							   {7CE165FB-61AA-409C-AFF0-12CEDA84E287}
AC_LanManager Hash							   {8633D6D1-2A33-4743-9C02-62960421985A}
AC_Password								   {71E1CC27-0998-40FC-8CDD-DB6D7596B004}
AU_InternetExplorer							   {D783D3F9-E742-4B10-83AB-FBD4A1FD9B96}
AU_Notification								   {7116D63A-7ED8-4717-8BA7-F73F13B6C967}
C_Software								   {882BE541-6E83-420A-94CF-535083E33ECF}
U_ActiveDirectory							   {CE0230F9-BCB3-41B1-A8B1-43519A234A54}
U_CMD									   {D6CD6FF9-2C3C-4D84-9230-6EA1B64304D2}
U_ControlPanel								   {613FA784-4204-4CD0-ABD4-BDD4CA15C47B}
U_RegEdit								   {2786B423-D998-4A1E-BE5D-50DE629AED8D}
U_RemovableDrive							   {06D49B76-7B32-4195-BAAD-4ABA8F41A099}

#>

param(
    [parameter(Mandatory=$true)]
    [String]
    $rootdir,

    [switch]
    $formatOutput
    )

$results = New-Object System.Collections.SortedList
Get-ChildItem -Recurse -Include backup.xml $rootdir | ForEach-Object {
    $guid = $_.Directory.Name
    $displayName = ([xml](gc $_)).GroupPolicyBackupScheme.GroupPolicyObject.GroupPolicyCoreSettings.DisplayName.InnerText
    $results.Add($displayName, $guid)
}

if ($formatOutput)
{
    $results | Format-Table -AutoSize
}
else
{
    $results
}
